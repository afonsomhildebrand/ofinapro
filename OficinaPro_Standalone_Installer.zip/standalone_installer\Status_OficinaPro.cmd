@echo off
powershell.exe -ExecutionPolicy Bypass -File "%~dp0status.ps1"
pause
